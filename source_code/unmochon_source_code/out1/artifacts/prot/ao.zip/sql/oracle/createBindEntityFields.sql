CREATE TABLE JdsBindEntityFields(
    EntityId    NUMBER(19),
    FieldId     NUMBER(19),
    PRIMARY KEY (EntityId,FieldId)
)