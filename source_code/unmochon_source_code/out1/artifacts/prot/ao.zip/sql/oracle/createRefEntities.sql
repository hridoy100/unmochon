CREATE TABLE JdsRefEntities(
    EntityId    NUMBER(19),
    EntityName  NCLOB,
    PRIMARY KEY (EntityId)
)