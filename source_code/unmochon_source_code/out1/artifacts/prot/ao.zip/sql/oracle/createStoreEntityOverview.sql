CREATE TABLE JdsStoreEntityOverview(
    EntityGuid      NVARCHAR2(48),
    DateCreated     DATE,
    DateModified    DATE,
    PRIMARY KEY     (EntityGuid)
)