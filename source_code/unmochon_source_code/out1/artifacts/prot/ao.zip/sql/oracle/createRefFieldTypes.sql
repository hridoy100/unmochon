CREATE TABLE JdsRefFieldTypes(
     TypeId         NUMBER(19),
     TypeName       NCLOB,
     PRIMARY KEY    (TypeId)
)