CREATE TABLE JdsRefFields(
     FieldId        NUMBER(19),
     FieldName      NCLOB,
     PRIMARY KEY    (FieldId)
)